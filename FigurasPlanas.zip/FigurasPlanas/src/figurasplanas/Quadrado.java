package figurasplanas;

public class Quadrado {
    private double lado;
    
     public Quadrado (double lado){
        setLado(lado);
    }
    
    public double getLado(){
        return lado;
    }
    
    public void setLado(double lado){
        if (lado <= 0) this.lado= 1;
        else this.lado=lado;
    }
    
    public double area(){
         return lado*lado; 
    }
    
    @Override
    public String toString(){
        return String.format("Quadrado \n Lado: %.2f \n Área: %.2f", lado, area());
    }
}
