package figurasplanas;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Quadrado q=new Quadrado (2);
        
        System.out.printf ("%s \n", q);
    }
    
}
