package tempo;

public class Tempo {
    private int hora;
    private int minutos;
    private int segundos;
    
    public Tempo (int hora){
        setHora(hora);
        setMin(minutos);
        setSeg(segundos);
    }
    
    public void setHora(int hora){
        if (hora < 0) this.hora= 1;
        else this.hora=hora;
    }
    
    public void setMin(int minutos){
        if (minutos < 0) this.minutos= 1;
        else this.minutos=minutos;
    }
    
    public void setSeg(int segundos){
        if (segundos < 0) this.segundos= 1;
        else this.segundos=segundos;
    }
    
    public Tempo (int hora, int minutos){
        setHora(hora);
        setMin(minutos);
        setSeg(segundos);
    }
    
    public Tempo (int hora, int minutos, int segundos){
        setHora(hora);
        setMin(minutos);
        setSeg(segundos);
    }
    
    public int getHora(){
        return hora;
    }
    
    public int getMin(){
        return minutos;
    }
    
    public int getSeg(){
        return segundos;
    }
    
    @Override
    public String toString(){
        if (minutos == 0 && segundos == 0){
            return String.format ("%s", hora);
        }
        else if (segundos == 0){
            return String.format ("%s:%s", hora, minutos);
        }
        else {
            return String.format ("%s:%s:%s", hora, minutos, segundos);
        }
    }
}
